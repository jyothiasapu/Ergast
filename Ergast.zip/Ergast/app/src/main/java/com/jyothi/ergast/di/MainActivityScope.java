package com.jyothi.ergast.di;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;

/**
 * Created by Jyothi on 16-02-2018.
 */

@Scope
@Retention(RetentionPolicy.CLASS)
public @interface MainActivityScope {
}
