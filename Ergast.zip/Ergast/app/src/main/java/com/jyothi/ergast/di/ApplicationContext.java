package com.jyothi.ergast.di;

import javax.inject.Qualifier;

/**
 * Created by Jyothi on 16-02-2018.
 */

@Qualifier
public @interface ApplicationContext {
}
