package com.jyothi.ergast.network;

/**
 * Created by jasapu on 22-02-2018.
 */

public enum CallStatus {
    RUNNING,
    SUCCESS,
    FAILED,
    MAX
}
